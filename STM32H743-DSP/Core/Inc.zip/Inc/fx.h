/*
 * fx.h
 *
 *  Created on: Apr 29, 2025
 *      Author: Hassa
 */

#ifndef INC_FX_H_
#define INC_FX_H_

#include "supro_simulation.h"
//#include "chorus.h"

/*
 *
 * Somehow create a generic effect handler here
 *
 */


#endif /* INC_FX_H_ */
