#ifndef H1_GAINCORRECTED_IR_H
#define H1_GAINCORRECTED_IR_H

#include "fir_struct.h"

extern __attribute__((aligned(32))) const float IR_FFT_ALL[2048];

extern __attribute__((aligned(32))) float prev_ffts_1[2048];

extern fir_t fir_h1_gaincorrected;


#endif
